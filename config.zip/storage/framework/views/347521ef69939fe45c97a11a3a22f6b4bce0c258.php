<?php if(Session::has('flash_message')): ?>
<div class="alert <?php echo e((Session::has('flash_message_status'))?'alert-error':'alert-success'); ?>">
    <button class="close" data-dismiss="alert" ></button>
    <?php echo Session::get('flash_message'); ?>

</div>
<?php endif; ?>