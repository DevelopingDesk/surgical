<?php $__env->startSection('content'); ?>


<div class="table-responsive"  data-example-id="contextual-table" >
    <button class="btn btn-primary pull-right" onclick="printContent('divide')">print</button>	

    <center><h2 style="color: red;margin-top: 10px">MAIN INDUSTRY SURGICAL</h2></center>
    <div id="divide">
      
    <table class="table" id="example">
      <thead>
        <tr>
          
             <th>id</th>
               <th>Product Name</th>
               <th>Product Quantity</th>
               <th>Product Size</th>
               
             
               <th>Date</th>
               
               
               
               <th>Color</th>
               
<th>   Cleaning</th>
<th>Send to Coating</th>
<th>Status Finish</th>



                
                        <?php if(Auth::User()->hasrole('admin')): ?>
                
                <th>Action</th>
               <?php endif; ?>
                
          
        </tr>
      </thead>
      <tbody>
       
       
      
       
     
        
        
           <?php $__currentLoopData = $unclean; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e($cls->id); ?></td>
                <td><?php echo e($cls->pname); ?></td>
                <td><?php echo e($cls->pquantity); ?></td>
                <td><?php echo e($cls->psize); ?></td>
             
               
                <td><?php echo e($cls->date); ?></td>
                
              
              
                <td><?php echo e($cls->color_id); ?></td>
                
                
              <?php if($cls->status_cleaning==null): ?>
               <td><input type="checkbox" name="shiftcleaning"></td>
               <?php else: ?>
               <td><h6 style="color: green">Recieved for cleaning</h6> </td>
<?php endif; ?>

              <?php if($cls->status_coating==null): ?>
               <td><input type="checkbox" name="shiftcoating" value="<?php echo e($cls->id); ?>"></td>

<?php else: ?>

               <td><input type="checkbox" name="shiftcoating" checked="true" value="<?php echo e($cls->id); ?>"></td>

              
               <?php endif; ?>
              <?php if($cls->status_coating==null): ?>
<td><h6 style="color: red"> Not finished</h6></td>
<?php else: ?>

<td><h6 style="color: green"> Finished</h6></td>
           <?php endif; ?>





                        <?php if(Auth::User()->hasrole('admin')): ?>
        
      
<td>
                <a href="" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-remove"></i> Delete</a>
             
               </td>
              <?php endif; ?>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
               
       
      </tbody>
    </table>
    </div>
    
   </div>

<script type="text/javascript">
  
  $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<script type="text/javascript">

function printContent(el){

var restorpage=document.body.innerHTML;
var printcontent=document.getElementById(el).innerHTML;

document.body.innerHTML=printcontent;
window.print();
document.body.innerHTML=restorpage;
window.close();
}
$('#saveOffer').click(function () {
  window.history.pushState('forward', null, '/');
  setTimeout(function () {
    window.location.reload();
},1000);
});

</script>

<script type="text/javascript" src="<?php echo e(asset('js/Stock/update.js')); ?>"></script>

<script type="text/javascript">
var token='<?php echo e(Session::token()); ?>';
var add='<?php echo e(route('shift.coating')); ?>';

</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>