<?php $__env->startSection('content'); ?>

<div class="col-md-12" style="margin-top: -50px" >
  <button class="btn btn-primary pull-right" onclick="printContent('divide')">print</button>

  <div style="background-color: white" id="divide">
    <br><br>
  <center><h2 style="color: red">MAIN INDUSTRY SURGICAL</h2></center>


<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
        
               <th>Product Name</th>
               <th>Product Quantity</th>
               <th>Product Size</th>
               <th>Customer Name</th>
               <th>Customer Phone</th>
               <th>Date</th>
               <th>Receipt Number</th>
               <th>Location</th>
               <th>Advance</th>
               <th>Color</th>
               <th>Serial Number</th>
               <th>Token Number</th>




                
                        <?php if(Auth::User()->hasrole('admin')): ?>
                
                <th>Delete</th>
               <?php endif; ?>
                

               
                
            </tr>
        </thead>
       
        <tbody>
          <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>

                <td><?php echo e($cls->pname); ?></td>
                <td><?php echo e($cls->pquantity); ?></td>
                <td><?php echo e($cls->psize); ?></td>
                <td><?php echo e($cls->cname); ?></td>
                <td><?php echo e($cls->cphone); ?></td>
                <td><?php echo e($cls->date); ?></td>
                <td><?php echo e($cls->rnumber); ?></td>
                <td><?php echo e($cls->location); ?></td>
                <td><?php echo e($cls->advance); ?></td>
                <td><?php echo e($cls->color_id); ?></td>
                <td><?php echo e($cls->serial_id); ?></td>
                <td><?php echo e($cls->token_id); ?></td>






        
      
<td>
                <a href="" class="btn btn-xs btn-danger"><i class="glyphicon glyphicon-remove"></i> Delete</a>
             
               </td>
              
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>

    </table>
  
   
   
    
    
       
<script type="text/javascript">
  
  $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
<script type="text/javascript">

function printContent(el){

var restorpage=document.body.innerHTML;
var printcontent=document.getElementById(el).innerHTML;

document.body.innerHTML=printcontent;
window.print();
document.body.innerHTML=restorpage;
window.close();
}
$('#saveOffer').click(function () {
  window.history.pushState('forward', null, '/');
  setTimeout(function () {
    window.location.reload();
},1000);
});

</script>

</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>